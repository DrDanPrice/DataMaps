Template.nav.onRendered(function () {
   //Need to call dropdown render    
    this.$('.ui.dropdown').dropdown(); 
});
//Use only for production
//Kadira.connect('StXxPxuZg6DgZGMJB', 'aa84dfbb-7bb7-49aa-9fe8-5a5f1216ba14');

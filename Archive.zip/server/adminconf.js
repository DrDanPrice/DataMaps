//Roles.createRole ( 'Collaborator' );
//Roles.createRole ( 'Editor' );

Accounts.config({
    sendVerificationEmail: true
    //forbidClientAccountCreation: false //interfered with yogiben:admin
});

/*AdminConfig = {
    name: 'DASH Data Maps',
    adminEmails: ['plindner@uh.edu']
};*/